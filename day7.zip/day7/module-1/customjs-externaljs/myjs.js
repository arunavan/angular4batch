$(document).ready(function(){
  $("button").click(function(){
    $("p").hide();
    $("h2").hide();
  <!--  $(this).hide();-->
  });
});
