// ajaxSubmit is part of the form plugin, *NOT*
// a standard part of jQuery.

function showParams4() {
  $("#form2").ajaxSubmit({ target: "#result3" });
}