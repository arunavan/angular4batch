package coreservlets;

import java.util.*;

public class JsonRpcTester {
  public double getRandomNumber() {
    return(Math.random());
  }
  
  public double getRandomNumber(double range) {
    return(range * Math.random());
  }
  
  public City getCity(String cityName) {
    return(CityUtils.getCity(cityName));
  }
  
  public List<City> findCities(String description) {
    return(CityUtils.findCities(description));
  }
}
