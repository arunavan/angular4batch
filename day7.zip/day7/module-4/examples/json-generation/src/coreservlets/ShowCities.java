package coreservlets;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

/** From <a href="http://courses.coreservlets.com/Course-Materials/">the
 *  coreservlets.com tutorials on servlets, JSP, Struts, JSF, Ajax, GWT, and Java</a>.
 */

public abstract class ShowCities extends HttpServlet {
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
      throws ServletException, IOException {
    response.setHeader("Cache-Control", "no-cache");
    response.setHeader("Pragma", "no-cache");
    response.setContentType("text/javascript");
    List<City> cities = getCities(request);
    outputCities(cities, request, response);
  }
  
  protected List<City> getCities(HttpServletRequest request) {
    String cityType = request.getParameter("cityType");
    return(CityUtils.findCities(cityType));
  }

  public void doPost(HttpServletRequest request,
                     HttpServletResponse response)
      throws ServletException, IOException {
    doGet(request, response);
  }
  
  public abstract void outputCities(List<City> cities, 
                                    HttpServletRequest request,
                                    HttpServletResponse response)
      throws ServletException, IOException;
}
