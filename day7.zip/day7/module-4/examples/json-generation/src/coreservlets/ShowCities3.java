package coreservlets;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import org.json.*;

/** From <a href="http://courses.coreservlets.com/Course-Materials/">the
 *  coreservlets.com tutorials on servlets, JSP, Struts, JSF, Ajax, GWT, and Java</a>.
 */

public class ShowCities3 extends ShowCities {
  protected List<City> getCities(HttpServletRequest request) {
    String cityNames = request.getParameter("cityNames");
    if ((cityNames == null) || (cityNames.trim().equals(""))) {
      cityNames = "['New York', 'Los Angeles]";
    }
    try {
      JSONArray jsonCityNames = new JSONArray(cityNames);
      List<City> cities = new ArrayList<City>();
      for(int i=0; i<jsonCityNames.length(); i++) {
        City city =
          CityUtils.getCityOrDefault(jsonCityNames.getString(i));
        cities.add(city);
      }
      return(cities);
    } catch(JSONException jse) {
      return(CityUtils.findCities("top-5-cities"));
    }
  }
  
  public void outputCities(List<City> cities,
                           HttpServletRequest request,
                           HttpServletResponse response)
      throws ServletException, IOException {
    PrintWriter out = response.getWriter();
    out.println(new JSONArray(cities, false));
  }
}
