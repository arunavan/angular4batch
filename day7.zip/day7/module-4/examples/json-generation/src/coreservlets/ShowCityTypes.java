package coreservlets;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.json.*;

/** From <a href="http://courses.coreservlets.com/Course-Materials/">the
 *  coreservlets.com tutorials on servlets, JSP, Struts, JSF, Ajax, GWT, and Java</a>.
 */

public class ShowCityTypes extends HttpServlet {
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
      throws ServletException, IOException {
    response.setHeader("Cache-Control", "no-cache");
    response.setHeader("Pragma", "no-cache");
    response.setContentType("text/javascript");
    PrintWriter out = response.getWriter();
    JSONObject cityTypes = 
      new JSONObject(CityUtils.getCityTypeMap());
    out.println(cityTypes);
  }

  public void doPost(HttpServletRequest request,
                     HttpServletResponse response)
      throws ServletException, IOException {
    doGet(request, response);
  }
}
