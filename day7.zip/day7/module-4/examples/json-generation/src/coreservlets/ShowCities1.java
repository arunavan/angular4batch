package coreservlets;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

/** From <a href="http://courses.coreservlets.com/Course-Materials/">the
 *  coreservlets.com tutorials on servlets, JSP, Struts, JSF, Ajax, GWT, and Java</a>.
 */

public class ShowCities1 extends ShowCities {
  public void outputCities(List<City> cities,
                           HttpServletRequest request,
                           HttpServletResponse response)
      throws ServletException, IOException {
    request.setAttribute("cities", cities);
    String outputPage = 
      "/WEB-INF/results/cities-json.jsp";
    RequestDispatcher dispatcher =
      request.getRequestDispatcher(outputPage);
    dispatcher.include(request, response);
  }
}
